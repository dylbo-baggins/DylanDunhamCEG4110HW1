package dylandunham.dylandunhamhw1;

import android.graphics.Color;

import java.util.Random;

/**
 * Class designed to generate 3 random RGB values, one for Red, Green, and Blue. It then takes these values to turn into one integer Android color value. Also converts
 * it to a hex string. All the variables are accesible via a getX call, except the randomValue variable.
 */
public class randomColor {
    private Random randomValue;
    private int color;
    private int red;
    private int green;
    private int blue;
    private String hex, hexR,hexB, hexG;

    public randomColor(){
        randomValue = new Random();
        red = randomValue.nextInt(256);
        green = randomValue.nextInt(256);
        blue = randomValue.nextInt(256);
        color = Color.rgb(red, green, blue);
        hexR = Integer.toHexString(red);
        hexG = Integer.toHexString(green);
        hexB = Integer.toHexString(blue);
        hex = Integer.toHexString(color);
    }
    public void newColor(){
        red = randomValue.nextInt(256);
        green = randomValue.nextInt(256);
        blue = randomValue.nextInt(256);
        color = Color.rgb(red, green, blue);
        hexR = Integer.toHexString(red);
        hexG = Integer.toHexString(green);
        hexB = Integer.toHexString(blue);
        hex = Integer.toHexString(color);
    }
    public int getRed(){
        return red;
    }
    public int getGreen(){
        return green;
    }
    public int getBlue(){
        return blue;
    }
    public String getHex(){ return hex;}
    public String getHexR(){ return hexR;}
    public String getHexG(){ return hexG;}
    public String getHexB(){ return hexB;}
    public int getColor(){
        return color;
    }

}

