package dylandunham.dylandunhamhw1;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import yuku.ambilwarna.AmbilWarnaDialog;

public class drawActivity extends AppCompatActivity {
    private static final int MY_WRITE =0;
    private int defaultColor;
    private drawCanvas thisCanvas;
    private boolean saveOn = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw);
        defaultColor = Color.BLACK;
        thisCanvas = (drawCanvas) findViewById(R.id.paintCanvas);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_WRITE);
        }
    }

    public void returnToMM(View view){
        Intent returnIntent = new Intent(this, MainMenu.class);
        startActivity(returnIntent);

    }
    public void colorSelect(View view){


        AmbilWarnaDialog colorSelector = new AmbilWarnaDialog(this, defaultColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                defaultColor = color;
                thisCanvas.setPaintColor(color);
            }
        });
        colorSelector.show();
    }
    public void clear(View view){
        setContentView(R.layout.activity_draw);
        thisCanvas = (drawCanvas) findViewById(R.id.paintCanvas);
    }
    public void save(View view){
        if (saveOn = true) {
            String filePathString = thisCanvas.saveImage();
            MediaScannerConnection.scanFile(this,
                    new String[]{filePathString}, null,
                    new MediaScannerConnection.OnScanCompletedListener() {

                        public void onScanCompleted(String path, Uri uri) {
                            Log.i("TAG", "Finished scanning " + path);
                        }
                    });
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_WRITE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    saveOn = true;
                } else {
                    saveOn = false;
                }
                return;
            }
        }
    }
}
