package dylandunham.dylandunhamhw1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;



public class writeActivity extends AppCompatActivity {
    private randomColor rColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);
        rColor = new randomColor();
    }
    public void returnToMM(View view){
        Intent returnIntent = new Intent(this, MainMenu.class);
        startActivity(returnIntent);

    }
    public void textRandomColor(View view){
        rColor.newColor();
        EditText writeBox2;
        writeBox2 = (EditText) findViewById(R.id.writeBox2);
        writeBox2.setTextColor(rColor.getColor());
        TextView colorCode;
        colorCode = (TextView) findViewById(R.id.colorCodeText2);
        String colorCodeString;
        colorCodeString = "COLOR: " + rColor.getRed() + "r, " + rColor.getGreen() + "g, " + rColor.getBlue() + "b, #" + rColor.getHex();
        colorCode.setText(colorCodeString);


    }
}
