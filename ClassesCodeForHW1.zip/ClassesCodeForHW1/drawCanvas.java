package dylandunham.dylandunhamhw1;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static android.util.Pair.create;

public class drawCanvas extends View {
    private Paint paint;
    private Path path;
    private List<Pair<Path, Integer>> path_color_list = new ArrayList<Pair<Path,Integer>>();
    private Canvas mCanvas;
    private Bitmap mBitmap;

    public drawCanvas(Context context, AttributeSet attrs) {

        super(context, attrs);

        paint = new Paint();
        path = new Path();
        paint.setAntiAlias(true);
        paint.setColor(Color.BLACK);
        path_color_list.add(create(path, paint.getColor()));
        paint.setStrokeJoin(Paint.Join.ROUND);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5f);
    }
    @Override
    protected void onDraw(Canvas canvas){
        this.setDrawingCacheEnabled(true);

        for (Pair<Path,Integer> path_clr : path_color_list ){
            paint.setColor(path_clr.second);
            canvas.drawPath( path_clr.first, paint);
            mCanvas.drawPath( path_clr.first, paint);
            mCanvas.drawBitmap(mBitmap,0,0,null);
        }
        super.onDraw(mCanvas);
        canvas.drawPath(path, paint);
        mCanvas.drawPath(path, paint);
        mCanvas.drawBitmap(mBitmap,0,0,null);


    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float xPos = event.getX();
        float yPos = event.getY();
        switch(event.getAction()){
            case MotionEvent.ACTION_DOWN:
                path.moveTo(xPos, yPos);
                return true;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(xPos, yPos);
                break;
            default:
                return false;
        }
        invalidate();
        return true;
    }

    public void setPaintColor(int color){
        int tmpPaint = paint.getColor();
        paint.setColor(color);
        path_color_list.add(create(path, tmpPaint));
        path = new Path();
        path_color_list.add(create(path, color));
    }
    public int getPaintColor(){
        return paint.getColor();
    }
    public void setStrokeJoin(Paint.Join join){
        paint.setStrokeJoin(join);
    }
    public Paint.Join getStrokeJoin(){
        return paint.getStrokeJoin();
    }
    public void setStyle(Paint.Style style){
        paint.setStyle(style);
    }
    public Paint.Style getStyle(){
        return paint.getStyle();
    }
    public void setStrokeWidth(float width){
        paint.setStrokeWidth(width);
    }
    public float getStrokeWidth(){
        return paint.getStrokeWidth();
    }
    public String saveImage(){
        Date today = new Date();
        Random randomValue;
        int number;
        randomValue = new Random();
        number = randomValue.nextInt(100000);
        try {


            File file = null;
            if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/drawAlbum/" + today + number + ".png");
                if(!file.exists()){
                    file.getParentFile().mkdirs();
                }



            }
            FileOutputStream ostream = new FileOutputStream(file);
            mBitmap.compress(Bitmap.CompressFormat.PNG, 10, ostream);
            ostream.close();
            return file.getAbsolutePath();



        } catch(Exception e){
            e.printStackTrace();
        }
        return "failure";
    }
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        mBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

        mCanvas = new Canvas(mBitmap);
        mCanvas.drawColor(Color.WHITE);
        setMeasuredDimension(width, height);


    }


}
