package dylandunham.dylandunhamhw1;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainMenu extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_menu);

    }
    public void startWrite(View view){
        Intent writeIntent = new Intent(this, writeActivity.class);
        startActivity(writeIntent);
    }
    public void startDraw(View view){
        Intent drawIntent = new Intent(this, drawActivity.class);
        startActivity(drawIntent);
    }

}
